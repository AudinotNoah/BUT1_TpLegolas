package libtest;

/**
 * gere une sortie de test
 * 
 * @author vthomas
 * 
 */
public interface Sortie {

	/**
	 * fait la mise a jour (exporte les logs ou change affichage)
	 */
	public void miseAjour(Logs logs);

}
